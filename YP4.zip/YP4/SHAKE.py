import pygame
import random

# Настройки игры
WIDTH, HEIGHT = 640, 480
CELL_SIZE = 20
GRID_WIDTH = WIDTH // CELL_SIZE
GRID_HEIGHT = HEIGHT // CELL_SIZE

# Цвета
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)

# Инициализация Pygame
pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Змейка")
clock = pygame.time.Clock()

class GameObject:
    def __init__(self, x, y, color):
        self.x = x
        self.y = y
        self.color = color

    def draw(self):
        pygame.draw.rect(screen, self.color, (self.x, self.y, CELL_SIZE, CELL_SIZE))

class Snake(GameObject):
    def __init__(self):
        super().__init__(20 * CELL_SIZE, 20 * CELL_SIZE, GREEN)  # Начальная позиция головы змейки
        self.body = [(self.x, self.y)]
        self.direction = (CELL_SIZE, 0)  # Начальное направление (вправо)

    def move(self):
        head_x, head_y = self.body[0]
        new_head = (head_x + self.direction[0], head_y + self.direction[1])
        self.body.insert(0, new_head)
        self.x, self.y = new_head

    def change_direction(self, new_direction):
        if (new_direction[0] * -1, new_direction[1] * -1) != self.direction:
            self.direction = new_direction

    def grow(self):
        # Добавляем новый сегмент в конец змейки
        self.body.append(self.body[-1])  # Дублируем последний сегмент

    def check_collision(self):
        return len(self.body) != len(set(self.body)) or not (0 <= self.x < WIDTH and 0 <= self.y < HEIGHT)

    def draw(self):
        for segment in self.body:
            pygame.draw.rect(screen, self.color, (segment[0], segment[1], CELL_SIZE, CELL_SIZE))

class Apple(GameObject):
    def __init__(self):
        super().__init__(0, 0, RED)
        self.spawn()

    def spawn(self):
        self.x = random.randint(0, GRID_WIDTH - 1) * CELL_SIZE
        self.y = random.randint(0, GRID_HEIGHT - 1) * CELL_SIZE

def main():
    snake = Snake()
    apple = Apple()
    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    snake.change_direction((0, -CELL_SIZE))
                elif event.key == pygame.K_DOWN:
                    snake.change_direction((0, CELL_SIZE))
                elif event.key == pygame.K_LEFT:
                    snake.change_direction((-CELL_SIZE, 0))
                elif event.key == pygame.K_RIGHT:
                    snake.change_direction((CELL_SIZE, 0))

        snake.move()

        # Проверка на поедание яблока
        if (snake.x, snake.y) == (apple.x, apple.y):
            snake.grow()
            apple.spawn()

        # Проверка на столкновение с собой или границами
        if snake.check_collision():
            running = False

        # Отрисовка
        screen.fill(BLACK)
        snake.draw()
        apple.draw()

        # Обновление экрана
        pygame.display.update()
        clock.tick(20)  # Устанавливаем FPS

    pygame.quit()

if __name__ == "__main__":
    main()
